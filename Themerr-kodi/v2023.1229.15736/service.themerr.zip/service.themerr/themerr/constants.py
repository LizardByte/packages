name = "Themerr"
addon_type = "service"
addon_id = f"{addon_type}.{name.lower()}"
