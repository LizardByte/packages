default_prefs = dict(
    str_youtube_user='',
    str_youtube_passwd='',
)
