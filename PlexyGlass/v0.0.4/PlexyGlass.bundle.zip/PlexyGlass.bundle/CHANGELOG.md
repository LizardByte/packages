# Changelog

## [0.0.4] - 2022-10-09
### Fixed
- use try/except/else for plexhints import
- docker build was missing some plugin files
- dockerignore file was not being respected
- issue with special characters being replaced in plist file

## [0.0.3] - 2022-10-04
### Fixed
- `plexhints` import error on Docker
- Reduced release bundle size
### Updated
- Improved documentation for Docker

## [0.0.2] - 2022-09-11
### Added
- Add docker-mod for linuxserver plex image

## [0.0.1] - 2022-09-09
### Added
- Initial Release
