# Changelog

## [0.0.3] - 2022-10-04
### Fixed
- `plexhints` import error on Docker
- Reduced release bundle size
### Updated
- Improved documentation for Docker

## [0.0.2] - 2022-09-11
### Added
- Add docker-mod for linuxserver plex image

## [0.0.1] - 2022-09-09
### Added
- Initial Release
