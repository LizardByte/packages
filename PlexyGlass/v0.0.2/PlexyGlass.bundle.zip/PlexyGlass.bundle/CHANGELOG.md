# Changelog

## [0.0.2] - 2022-09-11
### Added
- Add docker-mod for linuxserver plex image
- 
## [0.0.1] - 2022-09-09
### Added
- Initial Release
