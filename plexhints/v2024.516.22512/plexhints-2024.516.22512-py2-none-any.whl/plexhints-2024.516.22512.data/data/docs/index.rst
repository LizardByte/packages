:github_url: https://github.com/LizardByte/plexhints/tree/nightly/docs/source/index.rst

Table of Contents
=================
.. include:: toc.rst
