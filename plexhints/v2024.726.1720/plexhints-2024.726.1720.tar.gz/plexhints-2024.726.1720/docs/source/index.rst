:github_url: https://github.com/LizardByte/plexhints/blob/master/docs/source/index.rst

Table of Contents
=================
.. include:: toc.rst
