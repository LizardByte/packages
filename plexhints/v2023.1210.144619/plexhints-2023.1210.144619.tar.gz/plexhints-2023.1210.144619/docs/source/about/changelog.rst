Changelog
=========

.. only:: epub

   You can view the changelog in the
   `online version <https://github.com/LizardByte/plexhints/changelog/CHANGELOG.md>`__.

.. only:: html

   .. raw:: html

      <script type="module" src="https://md-block.verou.me/md-block.js"></script>
      <md-block
        hmin="2"
        src="https://raw.githubusercontent.com/LizardByte/plexhints/changelog/CHANGELOG.md">
      </md-block>
