:github_url: https://github.com/LizardByte/plexhints/blob/master/README.rst

.. include:: ../../../README.rst
