.. role:: modname
   :class: modname

.. role:: title
   :class: title
