:github_url: https://github.com/LizardByte/plexhints/blob/master/docs/source/framework/index.rst

Plex Plugin-in Framework documentation
======================================

References
----------

Plex Plugin-in Framework
^^^^^^^^^^^^^^^^^^^^^^^^

A mirror of Plex's Plugin-in Framework is included in our GitHub repository as a submodule, which can be found
`here <https://github.com/LizardByte/plexhints/tree/master/references>`__ or
`upstream <https://github.com/squaresmile/Plex-Plug-Ins/tree/master/Framework.bundle/Contents/Resources/Versions/2>`__.

Developer Documentation
^^^^^^^^^^^^^^^^^^^^^^^

An archive of the original developer documentation can be found
`here <https://web.archive.org/web/https://dev.plexapp.com/docs/index.html>`__.

.. todo:: Add original documentation here.
