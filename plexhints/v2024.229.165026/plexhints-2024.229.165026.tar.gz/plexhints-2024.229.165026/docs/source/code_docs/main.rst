:github_url: https://github.com/LizardByte/plexhints/tree/nightly/Contents/Code/__init__.py

.. include:: ../global.rst

:modname:`__init__`
------------------------
.. automodule:: Code
    :members:
    :show-inheritance:
