default_prefs = dict(
    int_upload_timeout='60',
    str_youtube_user='',
    str_youtube_passwd='',
    url_plex_server='http://localhost:32400'
)
