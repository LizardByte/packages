# Changelog

## [0.0.2] - 2022-10-04
### Fixed
- `plexhints` import error on Docker
- Reduced release bundle size

## [0.0.1] - 2022-10-03
### Added
- Initial Release
