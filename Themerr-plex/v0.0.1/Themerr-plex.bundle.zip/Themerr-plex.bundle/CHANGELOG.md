# Changelog

## [0.0.1] - 2022-10-03
### Added
- Initial Release
