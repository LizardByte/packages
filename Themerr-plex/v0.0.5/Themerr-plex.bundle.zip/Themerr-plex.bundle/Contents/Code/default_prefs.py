default_prefs = dict(
    int_plexapi_plexapi_timeout='180',
    str_youtube_user='',
    str_youtube_passwd='',
    url_plex_server='http://localhost:32400'
)
