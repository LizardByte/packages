default_prefs = dict(
    int_plexapi_plexapi_timeout='180',
    int_plexapi_upload_threads='3',
    str_youtube_user='',
    str_youtube_passwd=''
)
